# Deprecated and should not be used
import codewars_test as test

test.describe("group 1")
test.it("test 1")
test.assert_equals(1, 1)
