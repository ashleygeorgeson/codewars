# Deprecated and should not be used
import codewars_test as test

test.assert_equals(1, 2)
