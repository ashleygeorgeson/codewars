import codewars_test as test

test.assert_equals(1, 2)
test.assert_equals(1, 1)
