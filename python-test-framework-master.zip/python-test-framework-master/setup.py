from setuptools import setup

setup(
    name="codewars_test",
    version="0.1.0",
    packages=["codewars_test"],
    license="MIT",
    description="Codewars test framework for Python",
    install_requires=[],
    url="https://github.com/Codewars/python-test-framework",
)
